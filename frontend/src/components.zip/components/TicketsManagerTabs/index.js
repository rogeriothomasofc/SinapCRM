import React, { useContext, useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";

// Material UI imports atualizados para usar @mui/material em vez de @material-ui/core
import { styled, createTheme, ThemeProvider } from "@mui/material/styles";
import {
  Paper,
  InputBase,
  Tabs,
  Tab,
  Badge,
  FormControlLabel,
  Switch,
  Button,
  IconButton,
  Chip,
  Box,
  Tooltip,
  Divider,
  Typography
} from "@mui/material";

// Ícones modernos do MUI
import InboxOutlinedIcon from "@mui/icons-material/InboxOutlined";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import SearchIcon from "@mui/icons-material/Search";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";
import PriorityHighIcon from "@mui/icons-material/PriorityHigh";
import AccessTimeIcon from "@mui/icons-material/AccessTime";

// Componentes existentes
import NewTicketModal from "../NewTicketModal";
import TicketsList from "../TicketsListCustom";
import TabPanel from "../TabPanel";
import { i18n } from "../../translate/i18n";
import { AuthContext } from "../../context/Auth/AuthContext";
import { Can } from "../Can";
import TicketsQueueSelect from "../TicketsQueueSelect";
import { TagsFilter } from "../TagsFilter";
import { UsersFilter } from "../UsersFilter";

// Cores do tema principal do software
const mainThemeColor = {
  light: '#5d8aff', // Versão mais clara 
  main: '#2563eb', // Cor principal - um azul mais vibrante
  dark: '#1a44a8', // Versão mais escura
  contrastText: '#ffffff'
};

const secondaryThemeColor = {
  light: '#ff6e59',
  main: '#ff3f20', // Cor secundária - um vermelho/laranja vibrante
  dark: '#c52100',
  contrastText: '#ffffff'
};

// Tema customizado para os componentes MUI - movido para fora do componente
const theme = createTheme({
  palette: {
    primary: mainThemeColor,
    secondary: secondaryThemeColor,
  },
});

// Container principal responsivo
const MainContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  height: "100vh", // Usa toda a altura da viewport
  width: "100%",
  position: "relative",
  overflow: "hidden",
  backgroundColor: theme.palette.mode === "dark" ? "#121212" : "#f5f5f5",
}));

// Estilização moderna usando styled do MUI
const StyledTicketsWrapper = styled(Paper)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  height: "100%", // Ocupa toda a altura disponível
  width: "100%",
  maxWidth: "100%",
  margin: 0,
  overflow: "hidden",
  borderRadius: 0, // Sem bordas arredondadas para tela cheia
  boxShadow: "none", // Remove sombra para tela cheia
  backgroundColor: theme.palette.mode === "dark" ? "#1e1e2d" : "#ffffff",
}));

const StyledTabsHeader = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  padding: "8px 16px",
  backgroundColor: mainThemeColor.main,
  borderBottom: `1px solid ${theme.palette.mode === "dark" ? "#32324a" : "#e6e8f0"}`,
  minHeight: 56, // Altura mínima para o header
  flexShrink: 0,
}));

const StyledTabs = styled(Tabs)(({ theme }) => ({
  minHeight: 40,
  flex: 1,
  "& .MuiTabs-indicator": {
    height: 2,
    borderRadius: 2,
    backgroundColor: "#ffffff",
  },
}));

const StyledTab = styled(Tab)(({ theme }) => ({
  minHeight: 40,
  fontWeight: 500,
  fontSize: 13,
  minWidth: 80,
  textTransform: "none",
  borderRadius: 20,
  margin: "0 4px",
  padding: "6px 12px",
  color: "#ffffff",
  opacity: 0.7,
  "&.Mui-selected": {
    color: "#ffffff",
    fontWeight: 600,
    opacity: 1,
  },
}));

const StyledSearchBox = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  padding: "8px 16px",
  backgroundColor: theme.palette.mode === "dark" ? "#1e1e2d" : "#ffffff",
  borderBottom: `1px solid ${theme.palette.mode === "dark" ? "#32324a" : "#e6e8f0"}`,
  minHeight: 48,
  flexShrink: 0,
}));

const SearchInputWrapper = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  flex: 1,
  padding: "6px 12px",
  borderRadius: 20,
  backgroundColor: theme.palette.mode === "dark" ? "#2b2b40" : "#f5f6fa",
  marginRight: theme.spacing(1),
  "&:focus-within": {
    boxShadow: `0 0 0 2px ${mainThemeColor.main}`,
  },
}));

// Chip customizado para status dos tickets
const StatusChip = styled(Chip)(({ theme, isActive, colorScheme }) => ({
  height: 28,
  borderRadius: 14,
  fontSize: 12,
  fontWeight: 500,
  padding: "0 4px",
  marginRight: 8,
  backgroundColor: isActive ? colorScheme.main : 'transparent',
  borderColor: colorScheme.main,
  color: isActive ? "#fff" : colorScheme.main,
  '&:hover': {
    backgroundColor: isActive ? colorScheme.dark : `rgba(${parseInt(colorScheme.main.slice(1, 3), 16)}, ${parseInt(colorScheme.main.slice(3, 5), 16)}, ${parseInt(colorScheme.main.slice(5, 7), 16)}, 0.1)`,
  },
  '& .MuiChip-icon': {
    fontSize: 16,
    marginLeft: 6,
    marginRight: -4,
    color: isActive ? "#fff" : colorScheme.main,
  },
  '& .MuiChip-label': {
    display: 'flex',
    alignItems: 'center',
    padding: '0 8px',
  }
}));

// Container para área de conteúdo
const ContentArea = styled(Box)(({ theme }) => ({
  flex: 1,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden",
  position: "relative",
  minHeight: 0, // Importante para flex funcionar corretamente
}));

// Container scrollável aprimorado
const ScrollableContent = styled(Box)(({ theme }) => ({
  flex: 1,
  overflow: "auto",
  position: "relative",
  height: "100%",
  // Padding para o conteúdo não ficar colado nas bordas
  padding: theme.spacing(1),
  // Melhora performance do scroll
  WebkitOverflowScrolling: "touch",
  // Customização da scrollbar
  "&::-webkit-scrollbar": {
    width: 10,
    height: 10,
  },
  "&::-webkit-scrollbar-track": {
    backgroundColor: theme.palette.mode === "dark" ? "#2b2b40" : "#f1f1f1",
    borderRadius: 5,
  },
  "&::-webkit-scrollbar-thumb": {
    backgroundColor: theme.palette.mode === "dark" ? "#555" : "#888",
    borderRadius: 5,
    "&:hover": {
      backgroundColor: theme.palette.mode === "dark" ? "#666" : "#555",
    },
  },
  // Firefox
  scrollbarWidth: "thin",
  scrollbarColor: theme.palette.mode === "dark" ? "#555 #2b2b40" : "#888 #f1f1f1",
}));

// Box para os filtros expandidos
const FiltersBox = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1, 2),
  display: "flex",
  flexWrap: "wrap",
  alignItems: "center",
  gap: theme.spacing(1),
  borderBottom: `1px solid ${theme.palette.mode === "dark" ? "#32324a" : "#e6e8f0"}`,
  backgroundColor: theme.palette.mode === "dark" ? "#1e1e2d" : "#f8f9fa",
  minHeight: 48,
  flexShrink: 0,
}));

const ModernTicketsManagerTabs = () => {
  const history = useHistory();

  const [searchParam, setSearchParam] = useState("");
  const [tab, setTab] = useState("open");
  const [tabOpen, setTabOpen] = useState("open");
  const [newTicketModalOpen, setNewTicketModalOpen] = useState(false);
  const [showAllTickets, setShowAllTickets] = useState(false);
  const searchInputRef = useRef();
  const { user } = useContext(AuthContext);
  const { profile } = user;

  const [openCount, setOpenCount] = useState(0);
  const [pendingCount, setPendingCount] = useState(0);

  const userQueueIds = user.queues.map((q) => q.id);
  const [selectedQueueIds, setSelectedQueueIds] = useState(userQueueIds || []);
  const [selectedTags, setSelectedTags] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    if (user.profile.toUpperCase() === "ADMIN") {
      setShowAllTickets(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (tab === "search") {
      searchInputRef.current.focus();
    }
  }, [tab]);

  let searchTimeout;

  const handleSearch = (e) => {
    const searchedTerm = e.target.value.toLowerCase();

    clearTimeout(searchTimeout);

    if (searchedTerm === "") {
      setSearchParam(searchedTerm);
      setTab("open");
      return;
    }

    searchTimeout = setTimeout(() => {
      setSearchParam(searchedTerm);
    }, 500);
  };

  const handleChangeTab = (e, newValue) => {
    setTab(newValue);
  };

  const handleChangeTabOpen = (e, newValue) => {
    setTabOpen(newValue);
  };

  const applyPanelStyle = (status) => {
    if (tabOpen !== status) {
      return { display: "none" };
    }
    return { display: "block", height: "100%" };
  };

  const handleCloseOrOpenTicket = (ticket) => {
    setNewTicketModalOpen(false);
    if (ticket !== undefined && ticket.uuid !== undefined) {
      history.push(`/tickets/${ticket.uuid}`);
    }
  };

  const handleSelectedTags = (selecteds) => {
    const tags = selecteds.map((t) => t.id);
    setSelectedTags(tags);
  };

  const handleSelectedUsers = (selecteds) => {
    const users = selecteds.map((t) => t.id);
    setSelectedUsers(users);
  };
  
  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <ThemeProvider theme={theme}>
      <MainContainer>
        <StyledTicketsWrapper elevation={0}>
          <NewTicketModal
            modalOpen={newTicketModalOpen}
            onClose={(ticket) => {
              handleCloseOrOpenTicket(ticket);
            }}
          />

          {/* Header com tabs principal */}
          <StyledTabsHeader>
            <StyledTabs
              value={tab}
              onChange={handleChangeTab}
              variant="standard"
              TabIndicatorProps={{
                style: {
                  backgroundColor: "#ffffff"
                }
              }}
            >
              <StyledTab
                value="open"
                icon={
                  <Badge badgeContent={openCount + pendingCount} color="error">
                    <InboxOutlinedIcon fontSize="small" />
                  </Badge>
                }
                label={i18n.t("tickets.tabs.open.title")}
                iconPosition="start"
              />
              <StyledTab
                value="closed"
                icon={<CheckCircleOutlineIcon fontSize="small" />}
                label={i18n.t("tickets.tabs.closed.title")}
                iconPosition="start"
              />
              <StyledTab
                value="search"
                icon={<SearchIcon fontSize="small" />}
                label={i18n.t("tickets.tabs.search.title")}
                iconPosition="start"
              />
            </StyledTabs>
            
            {tab !== "search" && (
              <Tooltip title={i18n.t("ticketsManager.buttons.newTicket")}>
                <IconButton
                  sx={{ 
                    ml: 2,
                    color: "#ffffff",
                    '&:hover': {
                      backgroundColor: 'rgba(255, 255, 255, 0.1)'
                    }
                  }}
                  onClick={() => setNewTicketModalOpen(true)}
                  size="small"
                >
                  <AddCircleOutlineIcon />
                </IconButton>
              </Tooltip>
            )}
          </StyledTabsHeader>

          {/* Search bar e filtros */}
          <StyledSearchBox>
            {tab === "search" ? (
              <SearchInputWrapper>
                <SearchIcon sx={{ mr: 1, color: "text.secondary", fontSize: 20 }} />
                <InputBase
                  fullWidth
                  inputRef={searchInputRef}
                  placeholder={i18n.t("tickets.search.placeholder")}
                  type="search"
                  onChange={handleSearch}
                  sx={{ fontSize: 14 }}
                />
              </SearchInputWrapper>
            ) : (
              <>
                {tab === "open" && (
                  <Box sx={{ display: "flex", alignItems: "center", flex: 1 }}>
                    <StatusChip
                      icon={<InboxOutlinedIcon />}
                      label={
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Typography variant="body2" sx={{ fontSize: 12, fontWeight: 500, mr: 0.5 }}>
                            Atendendo
                          </Typography>
                          <Box sx={{ 
                            backgroundColor: tabOpen === "open" ? 'rgba(255, 255, 255, 0.2)' : mainThemeColor.light, 
                            borderRadius: '10px', 
                            px: 1, 
                            py: 0.25,
                            ml: 0.5,
                            fontSize: 11,
                            fontWeight: 'bold',
                            color: tabOpen === "open" ? '#fff' : mainThemeColor.dark
                          }}>
                            {openCount}
                          </Box>
                        </Box>
                      }
                      colorScheme={mainThemeColor}
                      isActive={tabOpen === "open"}
                      clickable
                      onClick={() => setTabOpen("open")}
                      variant={tabOpen === "open" ? "filled" : "outlined"}
                    />
                    <StatusChip
                      icon={<PriorityHighIcon />}
                      label={
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Typography variant="body2" sx={{ fontSize: 12, fontWeight: 500, mr: 0.5 }}>
                            Aguardando
                          </Typography>
                          <Box sx={{ 
                            backgroundColor: tabOpen === "pending" ? 'rgba(255, 255, 255, 0.2)' : secondaryThemeColor.light, 
                            borderRadius: '10px', 
                            px: 1, 
                            py: 0.25,
                            ml: 0.5,
                            fontSize: 11,
                            fontWeight: 'bold',
                            color: tabOpen === "pending" ? '#fff' : secondaryThemeColor.dark
                          }}>
                            {pendingCount}
                          </Box>
                        </Box>
                      }
                      colorScheme={secondaryThemeColor}
                      isActive={tabOpen === "pending"}
                      clickable
                      onClick={() => setTabOpen("pending")}
                      variant={tabOpen === "pending" ? "filled" : "outlined"}
                    />
                  </Box>
                )}
                
                <Box sx={{ display: "flex", alignItems: "center", ml: "auto" }}>
                  <Can
                    role={user.profile}
                    perform="tickets-manager:showall"
                    yes={() => (
                      <FormControlLabel
                        sx={{ mr: 1 }}
                        label={
                          <Box component="span" sx={{ fontSize: 13 }}>
                            {i18n.t("tickets.buttons.showAll")}
                          </Box>
                        }
                        labelPlacement="start"
                        control={
                          <Switch
                            size="small"
                            checked={showAllTickets}
                            onChange={() => setShowAllTickets((prevState) => !prevState)}
                            name="showAllTickets"
                            color="primary"
                            sx={{
                              '& .MuiSwitch-switchBase.Mui-checked': {
                                color: mainThemeColor.main,
                                '&:hover': {
                                  backgroundColor: 'rgba(37, 99, 235, 0.1)',
                                },
                              },
                              '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
                                backgroundColor: mainThemeColor.main,
                              },
                            }}
                          />
                        }
                      />
                    )}
                  />
                  
                  <Tooltip title={i18n.t("ticketsManager.tooltips.filters")}>
                    <IconButton 
                      size="small" 
                      color={showFilters ? "primary" : "default"}
                      onClick={toggleFilters}
                      sx={{ 
                        padding: 1,
                        color: showFilters ? mainThemeColor.main : 'inherit',
                        '&:hover': {
                          backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        }
                      }}
                    >
                      <FilterAltOutlinedIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
              </>
            )}
          </StyledSearchBox>
          
          {/* Filtros expandidos */}
          {showFilters && (
            <FiltersBox>
              <TicketsQueueSelect
                selectedQueueIds={selectedQueueIds}
                userQueues={user?.queues}
                onChange={(values) => setSelectedQueueIds(values)}
                size="small"
                sx={{ 
                  minWidth: 200,
                  '& .MuiOutlinedInput-root': { 
                    height: 36,
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: mainThemeColor.main,
                    }
                  } 
                }}
              />
              
              {tab === "search" && (
                <>
                  <TagsFilter 
                    onFiltered={handleSelectedTags} 
                    size="small"
                    sx={{ 
                      minWidth: 200,
                      '& .MuiOutlinedInput-root': { 
                        height: 36,
                        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: mainThemeColor.main,
                        }
                      } 
                    }}
                  />
                  {profile === "admin" && (
                    <UsersFilter 
                      onFiltered={handleSelectedUsers} 
                      size="small"
                      sx={{ 
                        minWidth: 200,
                        '& .MuiOutlinedInput-root': { 
                          height: 36,
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: mainThemeColor.main,
                          }
                        } 
                      }}
                    />
                  )}
                </>
              )}
            </FiltersBox>
          )}

          {/* Área de conteúdo principal */}
          <ContentArea>
            <TabPanel value={tab} name="open" sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
              <Box sx={{ display: "none" }}>
                <Tabs value={tabOpen} onChange={handleChangeTabOpen}>
                  <Tab value="open" />
                  <Tab value="pending" />
                </Tabs>
              </Box>
              <ScrollableContent>
                <Box style={applyPanelStyle("open")}>
                  <TicketsList
                    status="open"
                    showAll={showAllTickets}
                    selectedQueueIds={selectedQueueIds}
                    updateCount={(val) => setOpenCount(val)}
                  />
                </Box>
                <Box style={applyPanelStyle("pending")}>
                  <TicketsList
                    status="pending"
                    selectedQueueIds={selectedQueueIds}
                    updateCount={(val) => setPendingCount(val)}
                  />
                </Box>
              </ScrollableContent>
            </TabPanel>
            
            <TabPanel value={tab} name="closed" sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
              <ScrollableContent>
                <TicketsList
                  status="closed"
                  showAll={true}
                  selectedQueueIds={selectedQueueIds}
                />
              </ScrollableContent>
            </TabPanel>
            
            <TabPanel value={tab} name="search" sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
              <ScrollableContent>
                <TicketsList
                  searchParam={searchParam}
                  showAll={true}
                  tags={selectedTags}
                  users={selectedUsers}
                  selectedQueueIds={selectedQueueIds}
                />
              </ScrollableContent>
            </TabPanel>
          </ContentArea>
        </StyledTicketsWrapper>
      </MainContainer>
    </ThemeProvider>
  );
};

export default ModernTicketsManagerTabs;