import React, { useContext, useState } from "react";
import { useHistory } from "react-router-dom";

import { makeStyles, createTheme, ThemeProvider } from "@material-ui/core/styles";
import { 
  IconButton, 
  Tooltip, 
  Badge,
  Button
} from "@material-ui/core";
import { 
  MoreVert, 
  Replay, 
  CheckCircle, 
  UndoRounded 
} from "@material-ui/icons";

import { green } from '@material-ui/core/colors';
import { i18n } from "../../translate/i18n";
import api from "../../services/api";
import TicketOptionsMenu from "../TicketOptionsMenu";
import ButtonWithSpinner from "../ButtonWithSpinner";
import toastError from "../../errors/toastError";
import { AuthContext } from "../../context/Auth/AuthContext";
import { TicketsContext } from "../../context/Tickets/TicketsContext";

const useStyles = makeStyles(theme => ({
  actionButtonsContainer: {
    display: "flex",
    alignItems: "center",
    marginLeft: "auto",
    padding: theme.spacing(1),
  },
  actionButtons: {
    marginRight: theme.spacing(1),
    display: "flex",
    alignItems: "center",
    "& > *": {
      margin: theme.spacing(0.5),
    },
  },
  greenButton: {
    color: green[500],
    '&:hover': {
      backgroundColor: 'rgba(0, 150, 0, 0.08)',
    },
  },
  closeButton: {
    backgroundColor: green[500],
    color: "white",
    '&:hover': {
      backgroundColor: green[700],
    },
    boxShadow: '0px 3px 5px -1px rgba(0,0,0,0.2), 0px 6px 10px 0px rgba(0,0,0,0.14), 0px 1px 18px 0px rgba(0,0,0,0.12)',
  },
  returnButton: {
    marginRight: theme.spacing(1),
  },
  statusBadge: {
    marginRight: theme.spacing(2),
  },
  tooltips: {
    fontSize: '14px',
  },
}));

const TicketActionButtonsCustom = ({ ticket }) => {
  const classes = useStyles();
  const history = useHistory();
  const [anchorEl, setAnchorEl] = useState(null);
  const [loading, setLoading] = useState(false);
  const ticketOptionsMenuOpen = Boolean(anchorEl);
  const { user } = useContext(AuthContext);
  const { setCurrentTicket } = useContext(TicketsContext);

  const customTheme = createTheme({
    palette: {
      primary: green,
    },
  });

  const handleOpenTicketOptionsMenu = e => {
    setAnchorEl(e.currentTarget);
  };

  const handleCloseTicketOptionsMenu = e => {
    setAnchorEl(null);
  };

  const handleUpdateTicketStatus = async (e, status, userId) => {
    setLoading(true);
    try {
      await api.put(`/tickets/${ticket.id}`, {
        status: status,
        userId: userId || null,
        useIntegration: status === "closed" ? false : ticket.useIntegration,
        promptId: status === "closed" ? false : ticket.promptId,
        integrationId: status === "closed" ? false : ticket.integrationId
      });

      setLoading(false);
      if (status === "open") {
        setCurrentTicket({ ...ticket, code: "#open" });
      } else {
        setCurrentTicket({ id: null, code: null })
        history.push("/tickets");
      }
    } catch (err) {
      setLoading(false);
      toastError(err);
    }
  };

  const renderClosedTicketButtons = () => (
    <ButtonWithSpinner
      loading={loading}
      startIcon={<Replay />}
      size="small"
      variant="outlined"
      color="primary"
      onClick={e => handleUpdateTicketStatus(e, "open", user?.id)}
    >
      {i18n.t("messagesList.header.buttons.reopen")}
    </ButtonWithSpinner>
  );

  const renderPendingTicketButtons = () => (
    <ButtonWithSpinner
      loading={loading}
      size="small"
      variant="contained"
      color="primary"
      onClick={e => handleUpdateTicketStatus(e, "open", user?.id)}
    >
      {i18n.t("messagesList.header.buttons.accept")}
    </ButtonWithSpinner>
  );

  const renderOpenTicketButtons = () => (
    <>
      <Tooltip 
        title={i18n.t("messagesList.header.buttons.return")}
        classes={{ tooltip: classes.tooltips }}
      >
        <IconButton 
          onClick={e => handleUpdateTicketStatus(e, "pending", null)}
          className={classes.returnButton}
          disabled={loading}
        >
          <UndoRounded />
        </IconButton>
      </Tooltip>
      <ThemeProvider theme={customTheme}>
        <Tooltip 
          title={i18n.t("messagesList.header.buttons.resolve")}
          classes={{ tooltip: classes.tooltips }}
        >
          <IconButton 
            onClick={e => handleUpdateTicketStatus(e, "closed", user?.id)} 
            color="primary"
            disabled={loading}
          >
            <CheckCircle />
          </IconButton>
        </Tooltip>
      </ThemeProvider>
      <Tooltip 
        title={i18n.t("messagesList.header.buttons.options")}
        classes={{ tooltip: classes.tooltips }}
      >
        <IconButton onClick={handleOpenTicketOptionsMenu}>
          <MoreVert />
        </IconButton>
      </Tooltip>
      <TicketOptionsMenu
        ticket={ticket}
        anchorEl={anchorEl}
        menuOpen={ticketOptionsMenuOpen}
        handleClose={handleCloseTicketOptionsMenu}
      />
    </>
  );

  return (
    <div className={classes.actionButtonsContainer}>
      <div className={classes.actionButtons}>
        {ticket.status === "closed" && renderClosedTicketButtons()}
        {ticket.status === "open" && renderOpenTicketButtons()}
        {ticket.status === "pending" && renderPendingTicketButtons()}
      </div>
    </div>
  );
};

export default TicketActionButtonsCustom;