import React, { useState, useEffect, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import api from "../../services/api";
import { AuthContext } from "../../context/Auth/AuthContext";
import Board from "react-trello";
import { toast } from "react-toastify";
import { i18n } from "../../translate/i18n";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(2),
    backgroundColor: "#f5f7fa",
    minHeight: "100vh",
    "& .react-trello-board": {
      backgroundColor: "transparent",
      height: "auto",
      "& .react-trello-lane": {
        backgroundColor: "#ffffff",
        borderRadius: "16px",
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.08)",
        border: "1px solid #e8eaed",
        marginRight: theme.spacing(2),
        minWidth: "300px",
        maxWidth: "320px",
        "& header": {
          borderBottom: "2px solid #f0f2f5",
          borderRadius: "16px 16px 0 0",
          padding: "16px",
          "& .lane-header-name": {
            fontSize: "16px",
            fontWeight: "600",
            color: "#1a1a1a",
            fontFamily: theme.typography.fontFamily,
          },
          "& .lane-header-label": {
            backgroundColor: "#e3f2fd",
            color: "#1976d2",
            borderRadius: "20px",
            padding: "2px 12px",
            fontSize: "14px",
            fontWeight: "500",
            marginLeft: "8px",
          },
        },
        "& .lane-footer": {
          display: "none",
        },
        "& article.react-trello-card": {
          backgroundColor: "#ffffff",
          borderRadius: "12px",
          border: "1px solid #e8eaed",
          boxShadow: "0 1px 4px rgba(0, 0, 0, 0.06)",
          padding: "12px",
          margin: "8px",
          cursor: "pointer",
          transition: "all 0.2s ease",
          "&:hover": {
            transform: "translateY(-2px)",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.12)",
            borderColor: "#d1d5db",
          },
          "& header": {
            borderBottom: "1px solid #f0f2f5",
            paddingBottom: "8px",
            marginBottom: "8px",
            "& .card-title": {
              fontSize: "15px",
              fontWeight: "500",
              color: "#1a1a1a",
              lineHeight: "1.4",
            },
            "& .card-label": {
              backgroundColor: "#f0f4f8",
              color: "#5e6c84",
              borderRadius: "6px",
              padding: "2px 8px",
              fontSize: "12px",
              fontWeight: "500",
              float: "right",
            },
          },
          "& .card-description": {
            fontSize: "14px",
            color: "#5e6c84",
            "& p": {
              margin: "0 0 12px 0",
              lineHeight: "1.5",
              display: "-webkit-box",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
              textOverflow: "ellipsis",
            },
          },
        },
      },
    },
  },
  button: {
    background: "linear-gradient(135deg, #10a110 0%, #0d8f0d 100%)",
    border: "none",
    padding: "8px 16px",
    color: "white",
    fontWeight: "600",
    borderRadius: "8px",
    fontSize: "13px",
    cursor: "pointer",
    transition: "all 0.3s ease",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    "&:hover": {
      background: "linear-gradient(135deg, #0d8f0d 0%, #0a7a0a 100%)",
      transform: "translateY(-1px)",
      boxShadow: "0 4px 8px rgba(16, 161, 16, 0.3)",
    },
    "&:active": {
      transform: "translateY(0)",
    },
  },
  cardContent: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
  },
  contactInfo: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
    "& .phone": {
      fontSize: "13px",
      fontWeight: "500",
      color: "#374151",
      display: "flex",
      alignItems: "center",
      gap: "4px",
      "&:before": {
        content: '"📱"',
        fontSize: "12px",
      },
    },
    "& .message": {
      fontSize: "13px",
      color: "#6b7280",
      fontStyle: "italic",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      maxWidth: "100%",
    },
  },
  scrollContainer: {
    "&::-webkit-scrollbar": {
      height: "8px",
      width: "8px",
    },
    "&::-webkit-scrollbar-track": {
      background: "#f1f1f1",
      borderRadius: "10px",
    },
    "&::-webkit-scrollbar-thumb": {
      background: "#c1c1c1",
      borderRadius: "10px",
      "&:hover": {
        background: "#a8a8a8",
      },
    },
  },
}));

const Kanban = () => {
  const classes = useStyles();
  const history = useHistory();

  const [tags, setTags] = useState([]);

  const fetchTags = async () => {
    try {
      const response = await api.get("/tags/kanban");
      const fetchedTags = response.data.lista ?? [];

      setTags(fetchedTags);

      // Fetch tickets after fetching tags
      await fetchTickets(jsonString);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchTags();
  }, []);

  const [file, setFile] = useState({
    lanes: [],
  });

  const [tickets, setTickets] = useState([]);
  const { user } = useContext(AuthContext);
  const { profile, queues } = user;
  const jsonString = user.queues.map((queue) => queue.UserQueue.queueId);

  const fetchTickets = async (jsonString) => {
    try {
      const { data } = await api.get("/ticket/kanban", {
        params: {
          queueIds: JSON.stringify(jsonString),
          showAll: profile === "admin",
        },
      });

      setTickets(data.tickets);
    } catch (err) {
      console.log(err);
      setTickets([]);
    }
  };

  const popularCards = (jsonString) => {
    const filteredTickets = tickets.filter(
      (ticket) => ticket.tags.length === 0
    );

    const lanes = [
      {
        id: "lane0",
        title: i18n.t("kanban.open"),
        label: filteredTickets.length.toString(),
        cards: filteredTickets.map((ticket) => ({
          id: ticket.id.toString(),
          label: "Ticket #" + ticket.id.toString(),
          description: (
            <div className={classes.cardContent}>
              <div className={classes.contactInfo}>
                <span className="phone">{ticket.contact.number}</span>
                <span className="message">{ticket.lastMessage}</span>
              </div>
              <button
                className={classes.button}
                onClick={() => {
                  handleCardClick(ticket.uuid);
                }}
              >
                {i18n.t("kanban.seeTicket")}
              </button>
            </div>
          ),
          title: ticket.contact.name,
          draggable: true,
          href: "/tickets/" + ticket.uuid,
        })),
        style: {
          backgroundColor: "#f8fafc",
          borderTop: "3px solid #3b82f6",
        },
      },
      ...tags.map((tag) => {
        const tagsTickets = tickets.filter((ticket) => {
          const tagIds = ticket.tags.map((tag) => tag.id);
          return tagIds.includes(tag.id);
        });

        return {
          id: tag.id.toString(),
          title: tag.name,
          label: tagsTickets.length.toString(),
          cards: tagsTickets.map((ticket) => ({
            id: ticket.id.toString(),
            label: "Ticket #" + ticket.id.toString(),
            description: (
              <div className={classes.cardContent}>
                <div className={classes.contactInfo}>
                  <span className="phone">{ticket.contact.number}</span>
                  <span className="message">{ticket.lastMessage}</span>
                </div>
                <button
                  className={classes.button}
                  onClick={() => {
                    handleCardClick(ticket.uuid);
                  }}
                >
                  {i18n.t("kanban.seeTicket")}
                </button>
              </div>
            ),
            title: ticket.contact.name,
            draggable: true,
            href: "/tickets/" + ticket.uuid,
          })),
          style: { 
            backgroundColor: "#f8fafc",
            borderTop: `3px solid ${tag.color}`,
          },
          labelStyle: {
            backgroundColor: tag.color + "20",
            color: tag.color,
          },
        };
      }),
    ];

    setFile({ lanes });
  };

  const handleCardClick = (uuid) => {
    //console.log("Clicked on card with UUID:", uuid);
    history.push("/tickets/" + uuid);
  };

  useEffect(() => {
    popularCards(jsonString);
  }, [tags, tickets]);

  const handleCardMove = async (cardId, sourceLaneId, targetLaneId) => {
    try {
      await api.delete(`/ticket-tags/${targetLaneId}`);
      toast.success(i18n.t("kanban.toasts.removed"));
      await api.put(`/ticket-tags/${targetLaneId}/${sourceLaneId}`);
      toast.success(i18n.t("kanban.toasts.added"));
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className={`${classes.root} ${classes.scrollContainer}`}>
      <Board
        data={file}
        onCardMoveAcrossLanes={handleCardMove}
        style={{ 
          backgroundColor: "transparent",
          fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
        }}
        laneStyle={{
          backgroundColor: "#ffffff",
        }}
        cardStyle={{
          backgroundColor: "#ffffff",
        }}
      />
    </div>
  );
};

export default Kanban;