import React, { useState, useEffect } from "react";
import qs from 'query-string';
import * as Yup from "yup";
import { useHistory } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
import { toast } from "react-toastify";
import { Formik, Form, Field } from "formik";
import usePlans from "../../hooks/usePlans";
import moment from "moment";

// Material UI components
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import Link from "@material-ui/core/Link";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import Paper from "@material-ui/core/Paper";
import InputMask from 'react-input-mask';
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  InputAdornment,
  IconButton
} from "@material-ui/core";

// Icons
import { 
  PersonOutline, 
  EmailOutlined, 
  PhoneOutlined, 
  LockOutlined,
  Visibility,
  VisibilityOff,
  ViewListOutlined
} from "@material-ui/icons";

// Project imports
import logo from "../../assets/logo.png";
import { i18n } from "../../translate/i18n";
import { openApi } from "../../services/api";
import toastError from "../../errors/toastError";

const Copyright = () => {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {"Copyright © "}
      <Link color="inherit" href="#">
        PLW
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
};

const useStyles = makeStyles(theme => ({
  root: {
    width: "100vw",
    minHeight: "100vh",
    backgroundColor: theme.palette.primary.main,
    backgroundSize: "cover",
    backgroundPosition: "center",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    overflow: "hidden",
    padding: theme.spacing(2, 0)
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "40px 30px",
    borderRadius: "16px",
    boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)",
    position: "relative",
    zIndex: 2,
    backdropFilter: "blur(10px)",
    border: "1px solid rgba(255, 255, 255, 0.18)",
    maxWidth: "500px",
    width: "100%"
  },
  logoContainer: {
    marginBottom: theme.spacing(3),
    textAlign: "center"
  },
  logo: {
    width: "70%",
    maxWidth: "180px",
    margin: "0 auto",
  },
  form: {
    width: "100%",
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
    padding: "12px 0",
    borderRadius: "8px",
    fontWeight: 600,
    textTransform: "none",
    fontSize: "1rem",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    transition: "transform 0.2s, box-shadow 0.2s",
    "&:hover": {
      transform: "translateY(-2px)",
      boxShadow: "0 6px 12px rgba(0, 0, 0, 0.15)",
    }
  },
  textField: {
    marginBottom: theme.spacing(2),
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
      "& fieldset": {
        transition: "border-color 0.3s",
      },
      "&:hover fieldset": {
        borderColor: theme.palette.primary.main,
      },
    },
  },
  loginLink: {
    marginTop: theme.spacing(2),
    textAlign: "center",
    "& a": {
      color: theme.palette.primary.main,
      fontWeight: 500,
      transition: "color 0.2s",
      "&:hover": {
        color: theme.palette.primary.dark,
      }
    }
  },
  formControl: {
    width: "100%",
    "& .MuiOutlinedInput-root": {
      borderRadius: "8px",
    },
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  selectLabel: {
    backgroundColor: theme.palette.background.paper,
    padding: "0 5px",
    marginLeft: "-5px"
  },
  backgroundCircle: {
    position: "absolute",
    borderRadius: "50%",
    backgroundColor: theme.palette.primary.dark,
    opacity: 0.3,
  },
  circle1: {
    width: "300px",
    height: "300px",
    top: "-100px",
    right: "-100px",
  },
  circle2: {
    width: "500px",
    height: "500px",
    bottom: "-200px",
    left: "-200px",
    backgroundColor: theme.palette.secondary.main,
    opacity: 0.2,
  }
}));

const UserSchema = Yup.object().shape({
  name: Yup.string()
    .min(2, i18n.t("signup.formErrors.name.short"))
    .max(50, i18n.t("signup.formErrors.name.long"))
    .required(i18n.t("signup.formErrors.name.required")),
  password: Yup.string()
    .min(5, i18n.t("signup.formErrors.password.short"))
    .max(50, i18n.t("signup.formErrors.password.long"))
    .required(i18n.t("signup.formErrors.password.required")),
  email: Yup.string()
    .email(i18n.t("signup.formErrors.email.invalid"))
    .required(i18n.t("signup.formErrors.email.required")),
  phone: Yup.string()
    .required(i18n.t("signup.formErrors.phone.required") || "Telefone é obrigatório"),
  planId: Yup.string()
    .required(i18n.t("signup.formErrors.plan.required") || "Selecione um plano"),
});

const SignUp = () => {
  const classes = useStyles();
  const history = useHistory();
  let companyId = null;
  const [showPassword, setShowPassword] = useState(false);

  const params = qs.parse(window.location.search);
  if (params.companyId !== undefined) {
    companyId = params.companyId;
  }

  const initialState = { 
    name: "", 
    email: "", 
    phone: "", 
    password: "", 
    planId: "",
  };

  const [user] = useState(initialState);
  const dueDate = moment().add(3, "day").format();
  
  const handleSignUp = async values => {
    Object.assign(values, { recurrence: "MENSAL" });
    Object.assign(values, { dueDate: dueDate });
    Object.assign(values, { status: "t" });
    Object.assign(values, { campaignsEnabled: true });
    try {
      await openApi.post("/companies/cadastro", values);
      toast.success(i18n.t("signup.toasts.success"));
      history.push("/login");
    } catch (err) {
      console.log(err);
      toastError(err);
    }
  };

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const [plans, setPlans] = useState([]);
  const { list: listPlans } = usePlans();

  useEffect(() => {
    async function fetchData() {
      const list = await listPlans();
      setPlans(list);
    }
    fetchData();
  }, [listPlans]);

  return (
    <div className={classes.root}>
      {/* Background elements */}
      <div className={`${classes.backgroundCircle} ${classes.circle1}`}></div>
      <div className={`${classes.backgroundCircle} ${classes.circle2}`}></div>
      
      <Container component="main" maxWidth="sm">
        <CssBaseline />
        <Paper elevation={0} className={classes.paper}>
          <div className={classes.logoContainer}>
            <img className={classes.logo} src={logo} alt="Logo" />
          </div>
          
          <Typography component="h1" variant="h5" gutterBottom>
            {i18n.t("signup.title") !== "signup.title" ? i18n.t("signup.title") : "Criar Conta"}
          </Typography>
          
          <Typography variant="body2" color="textSecondary" paragraph>
            {i18n.t("signup.subtitle") !== "signup.subtitle" ? i18n.t("signup.subtitle") : "Preencha os dados para criar sua conta"}
          </Typography>
          
          <Formik
            initialValues={user}
            enableReinitialize={true}
            validationSchema={UserSchema}
            onSubmit={(values, actions) => {
              setTimeout(() => {
                handleSignUp(values);
                actions.setSubmitting(false);
              }, 400);
            }}
          >
            {({ touched, errors, isSubmitting }) => (
              <Form className={classes.form}>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <Field
                      as={TextField}
                      className={classes.textField}
                      autoComplete="name"
                      name="name"
                      error={touched.name && Boolean(errors.name)}
                      helperText={touched.name && errors.name}
                      variant="outlined"
                      fullWidth
                      id="name"
                      label={i18n.t("signup.form.name")}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <PersonOutline color="action" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <Field
                      as={TextField}
                      className={classes.textField}
                      variant="outlined"
                      fullWidth
                      id="email"
                      label={i18n.t("signup.form.email")}
                      name="email"
                      error={touched.email && Boolean(errors.email)}
                      helperText={touched.email && errors.email}
                      autoComplete="email"
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <EmailOutlined color="action" />
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  
                  <Grid item xs={12}>
                    <Field
                      as={InputMask}
                      mask="(99) 99999-9999"
                      variant="outlined"
                      fullWidth
                      id="phone"
                      name="phone"
                      error={touched.phone && Boolean(errors.phone)}
                      helperText={touched.phone && errors.phone}
                      autoComplete="phone"
                    >
                      {({ field }) => (
                        <TextField
                          {...field}
                          className={classes.textField}
                          variant="outlined"
                          fullWidth
                          label={i18n.t("signup.form.phone")}
                          error={touched.phone && Boolean(errors.phone)}
                          helperText={touched.phone && errors.phone}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">
                                <PhoneOutlined color="action" />
                              </InputAdornment>
                            ),
                          }}
                        />
                      )}
                    </Field>
                  </Grid>
                  
                  <Grid item xs={12}>
                    <Field
                      as={TextField}
                      className={classes.textField}
                      variant="outlined"
                      fullWidth
                      name="password"
                      error={touched.password && Boolean(errors.password)}
                      helperText={touched.password && errors.password}
                      label={i18n.t("signup.form.password")}
                      type={showPassword ? "text" : "password"}
                      id="password"
                      autoComplete="current-password"
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <LockOutlined color="action" />
                          </InputAdornment>
                        ),
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="toggle password visibility"
                              onClick={handleTogglePasswordVisibility}
                              edge="end"
                            >
                              {showPassword ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>
                  
                  <Grid item xs={12}>
                    <FormControl variant="outlined" className={classes.formControl} error={touched.planId && Boolean(errors.planId)}>
                      <InputLabel id="plan-label" className={classes.selectLabel}>
                        {i18n.t("signup.form.plan") || "Plano"}
                      </InputLabel>
                      <Field
                        as={Select}
                        labelId="plan-label"
                        variant="outlined"
                        fullWidth
                        id="planId"
                        label={i18n.t("signup.form.plan") || "Plano"}
                        name="planId"
                        startAdornment={
                          <InputAdornment position="start">
                            <ViewListOutlined color="action" />
                          </InputAdornment>
                        }
                      >
                        {plans.map((plan, key) => (
                          <MenuItem key={key} value={plan.id}>
                            {plan.name} - {i18n.t("signup.plan.attendant") || "Atendentes"}: {plan.users} - {i18n.t("signup.plan.whatsapp") || "WhatsApp"}: {plan.connections} - {i18n.t("signup.plan.queues") || "Filas"}: {plan.queues} - R$ {plan.value}
                          </MenuItem>
                        ))}
                      </Field>
                      {touched.planId && errors.planId && (
                        <Typography variant="caption" color="error">
                          {errors.planId}
                        </Typography>
                      )}
                    </FormControl>
                  </Grid>
                </Grid>
                
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  className={classes.submit}
                  disabled={isSubmitting}
                >
                  {i18n.t("signup.buttons.submit") || "Cadastrar"}
                </Button>
                
                <Grid container justifyContent="center">
                  <Grid item className={classes.loginLink}>
                    <Link
                      component={RouterLink}
                      to="/login"
                      variant="body2"
                    >
                      {i18n.t("signup.buttons.login") || "Já tem uma conta? Faça login"}
                    </Link>
                  </Grid>
                </Grid>
              </Form>
            )}
          </Formik>
        </Paper>
        <Box mt={4}><Copyright /></Box>
      </Container>
    </div>
  );
};

export default SignUp;