import React, { useState, useEffect, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Paper,
  Typography,
  Container,
  Select,
  MenuItem,
  FormControl,
  Box,
  Divider,
  CircularProgress,
  Fade,
  Chip,
  Switch,
  FormControlLabel,
  Grid,
  useTheme,
} from "@material-ui/core";
import SettingsIcon from "@material-ui/icons/Settings";
import SecurityIcon from "@material-ui/icons/Security";
import PersonAddIcon from "@material-ui/icons/PersonAdd";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import CancelIcon from "@material-ui/icons/Cancel";

import { toast } from "react-toastify";
import api from "../../services/api";
import { i18n } from "../../translate/i18n.js";
import toastError from "../../errors/toastError";
import { SocketContext } from "../../context/Socket/SocketContext";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    backgroundColor: theme.palette.background.default,
  },
  header: {
    padding: theme.spacing(3),
    backgroundColor: theme.palette.background.paper,
    borderBottom: `1px solid ${theme.palette.divider}`,
  },
  headerContent: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(2),
  },
  headerIcon: {
    color: theme.palette.primary.main,
  },
  headerTitle: {
    fontWeight: 700,
    fontSize: "1.5rem",
    color: theme.palette.text.primary,
  },
  headerSubtitle: {
    color: theme.palette.text.secondary,
    marginTop: theme.spacing(0.5),
  },
  container: {
    flex: 1,
    overflowY: "auto",
    padding: theme.spacing(3),
  },
  section: {
    marginBottom: theme.spacing(3),
  },
  sectionTitle: {
    fontWeight: 600,
    fontSize: "1.1rem",
    color: theme.palette.text.primary,
    marginBottom: theme.spacing(2),
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
  },
  settingCard: {
    padding: theme.spacing(2.5),
    marginBottom: theme.spacing(1.5),
    borderRadius: 8,
    border: `1px solid ${theme.palette.divider}`,
    backgroundColor: theme.palette.background.paper,
    transition: "all 0.2s ease",
    "&:hover": {
      borderColor: theme.palette.primary.main,
      boxShadow: theme.shadows[2],
    },
  },
  settingRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: theme.spacing(2),
  },
  settingInfo: {
    flex: 1,
  },
  settingLabel: {
    fontWeight: 500,
    fontSize: "0.9375rem",
    color: theme.palette.text.primary,
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: "0.8125rem",
    color: theme.palette.text.secondary,
    lineHeight: 1.5,
  },
  select: {
    minWidth: 200,
    "& .MuiOutlinedInput-root": {
      borderRadius: 6,
      fontSize: "0.875rem",
      "& fieldset": {
        borderColor: theme.palette.divider,
      },
      "&:hover fieldset": {
        borderColor: theme.palette.primary.main,
      },
    },
  },
  statusChip: {
    fontWeight: 500,
    fontSize: "0.75rem",
  },
  enabledChip: {
    backgroundColor: theme.palette.success.light,
    color: theme.palette.success.dark,
  },
  disabledChip: {
    backgroundColor: theme.palette.error.light,
    color: theme.palette.error.dark,
  },
  loadingContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
    padding: theme.spacing(4),
  },
  emptyState: {
    textAlign: "center",
    padding: theme.spacing(6),
    color: theme.palette.text.secondary,
  },
}));

const Settings = () => {
  const classes = useStyles();
  const theme = useTheme();
  const [settings, setSettings] = useState([]);
  const [loading, setLoading] = useState(true);
  const socketManager = useContext(SocketContext);

  useEffect(() => {
    const fetchSession = async () => {
      try {
        const { data } = await api.get("/settings");
        setSettings(data);
        setLoading(false);
      } catch (err) {
        toastError(err);
        setLoading(false);
      }
    };
    fetchSession();
  }, []);

  useEffect(() => {
    const companyId = localStorage.getItem("companyId");
    const socket = socketManager.getSocket(companyId);
    
    socket.on(`company-${companyId}-settings`, (data) => {
      if (data.action === "update") {
        setSettings((prevState) => {
          const aux = [...prevState];
          const settingIndex = aux.findIndex((s) => s.key === data.setting.key);
          if (settingIndex !== -1) {
            aux[settingIndex].value = data.setting.value;
          }
          return aux;
        });
      }
    });
    
    return () => {
      socket.disconnect();
    };
  }, [socketManager]);

  const handleChangeSetting = async (e) => {
    const selectedValue = e.target.value;
    const settingKey = e.target.name;
    
    try {
      await api.put(`/settings/${settingKey}`, {
        value: selectedValue,
      });
      toast.success(i18n.t("settings.success"));
    } catch (err) {
      toastError(err);
    }
  };

  const handleToggleSetting = async (settingKey, currentValue) => {
    const newValue = currentValue === "enabled" ? "disabled" : "enabled";
    
    try {
      await api.put(`/settings/${settingKey}`, {
        value: newValue,
      });
      toast.success(i18n.t("settings.success"));
    } catch (err) {
      toastError(err);
    }
  };

  const getSettingValue = (key) => {
    const setting = settings.find((s) => s.key === key);
    return setting ? setting.value : "";
  };

  const renderStatusChip = (value) => {
    const isEnabled = value === "enabled";
    return (
      <Chip
        size="small"
        icon={isEnabled ? <CheckCircleIcon /> : <CancelIcon />}
        label={
          isEnabled
            ? i18n.t("settings.settings.userCreation.options.enabled")
            : i18n.t("settings.settings.userCreation.options.disabled")
        }
        className={`${classes.statusChip} ${
          isEnabled ? classes.enabledChip : classes.disabledChip
        }`}
      />
    );
  };

  if (loading) {
    return (
      <Box className={classes.loadingContainer}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <div className={classes.root}>
      <Box className={classes.header}>
        <Box className={classes.headerContent}>
          <SettingsIcon fontSize="large" className={classes.headerIcon} />
          <Box>
            <Typography className={classes.headerTitle}>
              {i18n.t("settings.title")}
            </Typography>
            <Typography variant="body2" className={classes.headerSubtitle}>
              {i18n.t("settings.subtitle") || "Gerencie as configurações do sistema"}
            </Typography>
          </Box>
        </Box>
      </Box>

      <Container className={classes.container} maxWidth="md">
        <Fade in={true} timeout={500}>
          <Box className={classes.section}>
            <Typography className={classes.sectionTitle}>
              <SecurityIcon fontSize="small" />
              {i18n.t("settings.sections.security") || "Segurança e Acesso"}
            </Typography>

            <Paper className={classes.settingCard} elevation={0}>
              <Box className={classes.settingRow}>
                <Box className={classes.settingInfo}>
                  <Typography className={classes.settingLabel}>
                    <PersonAddIcon style={{ fontSize: 18, marginRight: 8, verticalAlign: "middle" }} />
                    {i18n.t("settings.settings.userCreation.name")}
                  </Typography>
                  <Typography className={classes.settingDescription}>
                    {i18n.t("settings.settings.userCreation.description") || 
                     "Controle se novos usuários podem se registrar no sistema"}
                  </Typography>
                </Box>
                
                <Box display="flex" alignItems="center" gap={2}>
                  {renderStatusChip(getSettingValue("userCreation"))}
                  
                  <FormControl size="small" variant="outlined">
                    <Select
                      id="userCreation-setting"
                      name="userCreation"
                      value={getSettingValue("userCreation")}
                      onChange={handleChangeSetting}
                      className={classes.select}
                    >
                      <MenuItem value="enabled">
                        {i18n.t("settings.settings.userCreation.options.enabled")}
                      </MenuItem>
                      <MenuItem value="disabled">
                        {i18n.t("settings.settings.userCreation.options.disabled")}
                      </MenuItem>
                    </Select>
                  </FormControl>
                </Box>
              </Box>
            </Paper>
          </Box>
        </Fade>

        {settings.length === 0 && !loading && (
          <Box className={classes.emptyState}>
            <SettingsIcon style={{ fontSize: 48, marginBottom: 16, opacity: 0.2 }} />
            <Typography variant="body1">
              {i18n.t("settings.noSettings") || "Nenhuma configuração disponível"}
            </Typography>
          </Box>
        )}
      </Container>
    </div>
  );
};

export default Settings;