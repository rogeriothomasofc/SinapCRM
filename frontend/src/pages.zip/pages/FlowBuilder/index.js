import React, { useState, useEffect, useReducer, useContext } from "react";

import { toast } from "react-toastify";
import { useHistory } from "react-router-dom";

import { makeStyles } from "@material-ui/core/styles";
import {
  Paper,
  TextField,
  InputAdornment,
  Typography,
  Box,
  Button,
  Chip,
  Fade,
  IconButton,
  Menu,
  MenuItem,
  Divider
} from "@material-ui/core";

// Importações do MUI (material-ui/icons)
import SearchIcon from "@material-ui/icons/Search";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import EditIcon from "@material-ui/icons/Edit";
import FileCopyIcon from "@material-ui/icons/FileCopy";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import BuildIcon from "@material-ui/icons/Build";
import OfflineBoltIcon from "@material-ui/icons/OfflineBolt";

// Componente CircularProgress
import { CircularProgress } from "@mui/material";

import api from "../../services/api";
import ConfirmationModal from "../../components/ConfirmationModal";

import { i18n } from "../../translate/i18n";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import MainContainer from "../../components/MainContainer";
import toastError from "../../errors/toastError";
import { AuthContext } from "../../context/Auth/AuthContext";
import NewTicketModal from "../../components/NewTicketModal";

import FlowBuilderModal from "../../components/FlowBuilderModal";

const reducer = (state, action) => {
  if (action.type === "LOAD_CONTACTS") {
    const contacts = action.payload;
    const newContacts = [];

    contacts.forEach((contact) => {
      const contactIndex = state.findIndex((c) => c.id === contact.id);
      if (contactIndex !== -1) {
        state[contactIndex] = contact;
      } else {
        newContacts.push(contact);
      }
    });

    return [...state, ...newContacts];
  }

  if (action.type === "UPDATE_CONTACTS") {
    const contact = action.payload;
    const contactIndex = state.findIndex((c) => c.id === contact.id);

    if (contactIndex !== -1) {
      state[contactIndex] = contact;
      return [...state];
    } else {
      return [contact, ...state];
    }
  }

  if (action.type === "DELETE_CONTACT") {
    const contactId = action.payload;

    const contactIndex = state.findIndex((c) => c.id === contactId);
    if (contactIndex !== -1) {
      state.splice(contactIndex, 1);
    }
    return [...state];
  }

  if (action.type === "RESET") {
    return [];
  }
};

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    borderRadius: 12,
    padding: theme.spacing(2),
    overflowY: "scroll",
    ...theme.scrollbarStyles,
  },
  searchBar: {
    background: "#f9f9f9",
    borderRadius: 50,
    padding: theme.spacing(0.5, 2),
    marginRight: theme.spacing(2),
    width: 250,
    transition: "all 0.3s ease",
    "&:focus-within": {
      boxShadow: "0 3px 8px rgba(0,0,0,0.1)",
      background: "#fff",
    },
  },
  addButton: {
    borderRadius: 30,
    boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
    fontWeight: "bold",
  },
  flowCounter: {
    display: "inline-flex",
    alignItems: "center",
    padding: theme.spacing(0.75, 1.5),
    borderRadius: 20,
    background: theme.palette.primary.main,
    color: "white",
    fontWeight: 500,
    fontSize: "0.875rem",
    marginLeft: theme.spacing(2),
  },
  flowsContainer: {
    display: "flex",
    flexDirection: "column",
    width: "100%",
    gap: theme.spacing(1.5),
  },
  flowItem: {
    width: "100%",
    borderRadius: 8,
    border: "1px solid #e0e0e0",
    padding: theme.spacing(2),
    transition: "all 0.2s ease",
    backgroundColor: "#fff",
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    cursor: "pointer",
    "&:hover": {
      boxShadow: "0 2px 5px rgba(0,0,0,0.08)",
      borderColor: "#bdbdbd",
    },
  },
  flowName: {
    fontWeight: 500,
    display: "flex",
    alignItems: "center",
  },
  flowIcon: {
    marginRight: theme.spacing(1),
    color: theme.palette.primary.main,
  },
  actionButton: {
    padding: theme.spacing(0.5),
    width: 36,
    height: 36,
  },
  emptyState: {
    textAlign: "center",
    padding: theme.spacing(4),
    color: theme.palette.text.secondary,
  },
  headerActions: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
  },
  menuItem: {
    minHeight: 'auto',
    fontSize: '0.9rem',
  },
  menuIcon: {
    marginRight: theme.spacing(1),
    fontSize: '1.2rem',
  },
  divider: {
    margin: theme.spacing(1, 0),
  }
}));

const FlowBuilder = () => {
  const classes = useStyles();
  const history = useHistory();

  const [loading, setLoading] = useState(false);
  const [pageNumber, setPageNumber] = useState(1);
  const [searchParam, setSearchParam] = useState("");
  const [contacts, dispatch] = useReducer(reducer, []);
  const [webhooks, setWebhooks] = useState([]);
  const [selectedContactId, setSelectedContactId] = useState(null);
  const [selectedWebhookName, setSelectedWebhookName] = useState(null);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [newTicketModalOpen, setNewTicketModalOpen] = useState(false);
  const [contactTicket, setContactTicket] = useState({});
  const [deletingContact, setDeletingContact] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmDuplicateOpen, setConfirmDuplicateOpen] = useState(false);

  const [hasMore, setHasMore] = useState(false);
  const [reloadData, setReloadData] = useState(false);
  const { user, socket } = useContext(AuthContext);

  useEffect(() => {
    dispatch({ type: "RESET" });
    setPageNumber(1);
  }, [searchParam]);

  useEffect(() => {
    setLoading(true);
    const delayDebounceFn = setTimeout(() => {
      const fetchContacts = async () => {
        try {
          const { data } = await api.get("/flowbuilder");
          setWebhooks(data.flows);
          dispatch({ type: "LOAD_CONTACTS", payload: data.flows });
          setHasMore(data.hasMore);
        } catch (err) {
          toastError(err);
        } finally {
          setLoading(false);
        }
      };
      fetchContacts();
    }, 500);
    return () => clearTimeout(delayDebounceFn);
  }, [searchParam, pageNumber, reloadData]);

  const handleSearch = (event) => {
    setSearchParam(event.target.value.toLowerCase());
  };

  const handleOpenContactModal = () => {
    setSelectedContactId(null);
    setContactModalOpen(true);
  };

  const handleCloseContactModal = () => {
    setSelectedContactId(null);
    setContactModalOpen(false);
  };

  const handleCloseOrOpenTicket = (ticket) => {
    setNewTicketModalOpen(false);
    if (ticket !== undefined && ticket.uuid !== undefined) {
      history.push(`/tickets/${ticket.uuid}`);
    }
  };

  const hadleEditContact = () => {
    setSelectedContactId(deletingContact.id);
    setSelectedWebhookName(deletingContact.name);
    setContactModalOpen(true);
  };

  const handleDeleteWebhook = async (webhookId) => {
    try {
      await api.delete(`/flowbuilder/${webhookId}`).then((res) => {
        setDeletingContact(null);
        setReloadData((old) => !old);
      });
      toast.success("Fluxo excluído com sucesso");
    } catch (err) {
      toastError(err);
    }
  };

  const handleDuplicateFlow = async (flowId) => {
    try {
      await api
        .post(`/flowbuilder/duplicate`, { flowId: flowId })
        .then((res) => {
          setDeletingContact(null);
          setReloadData((old) => !old);
        });
      toast.success("Fluxo duplicado com sucesso");
    } catch (err) {
      toastError(err);
    }
  };

  const loadMore = () => {
    setPageNumber((prevState) => prevState + 1);
  };

  const handleScroll = (e) => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - (scrollTop + 100) < clientHeight) {
      loadMore();
    }
  };

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event, contact) => {
    event.stopPropagation();
    setAnchorEl(event.currentTarget);
    setDeletingContact(contact);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const exportLink = () => {
    history.push(`/flowbuilder/${deletingContact.id}`);
  };

  const getActiveFlowsCount = () => {
    return webhooks.filter(flow => flow.active).length;
  };

  const getInactiveFlowsCount = () => {
    return webhooks.filter(flow => !flow.active).length;
  };

  return (
    <MainContainer>
      <NewTicketModal
        modalOpen={newTicketModalOpen}
        initialContact={contactTicket}
        onClose={(ticket) => {
          handleCloseOrOpenTicket(ticket);
        }}
      />

      <FlowBuilderModal
        open={contactModalOpen}
        onClose={handleCloseContactModal}
        aria-labelledby="form-dialog-title"
        flowId={selectedContactId}
        nameWebhook={selectedWebhookName}
        onSave={() => setReloadData((old) => !old)}
      />

      <ConfirmationModal
        title={
          deletingContact
            ? `${i18n.t("contacts.confirmationModal.deleteTitle")} ${
                deletingContact.name
              }?`
            : `${i18n.t("contacts.confirmationModal.importTitlte")}`
        }
        open={confirmOpen}
        onClose={setConfirmOpen}
        onConfirm={(e) =>
          deletingContact ? handleDeleteWebhook(deletingContact.id) : () => {}
        }
      >
        {deletingContact
          ? `Tem certeza que deseja deletar este fluxo? Todas as integrações relacionados serão perdidos.`
          : `${i18n.t("contacts.confirmationModal.importMessage")}`}
      </ConfirmationModal>

      <ConfirmationModal
        title={
          deletingContact
            ? `Deseja duplicar o fluxo ${deletingContact.name}?`
            : `${i18n.t("contacts.confirmationModal.importTitlte")}`
        }
        open={confirmDuplicateOpen}
        onClose={setConfirmDuplicateOpen}
        onConfirm={(e) =>
          deletingContact ? handleDuplicateFlow(deletingContact.id) : () => {}
        }
      >
        {deletingContact
          ? `Tem certeza que deseja duplicar este fluxo?`
          : `${i18n.t("contacts.confirmationModal.importMessage")}`}
      </ConfirmationModal>

      <MainHeader>
        <Box display="flex" alignItems="center">
          <Title>Fluxos de conversa</Title>
          <Chip 
            label={webhooks.length}
            color="primary"
            size="small"
            className={classes.flowCounter}
            icon={<OfflineBoltIcon style={{ color: "white", fontSize: 16 }} />}
          />
        </Box>
        <MainHeaderButtonsWrapper>
          <Box className={classes.headerActions}>
            <TextField
              placeholder={i18n.t("contacts.searchPlaceholder")}
              type="search"
              value={searchParam}
              onChange={handleSearch}
              className={classes.searchBar}
              variant="standard"
              InputProps={{
                disableUnderline: true,
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon style={{ color: "gray" }} />
                  </InputAdornment>
                ),
              }}
            />
            <Button
              variant="contained"
              onClick={handleOpenContactModal}
              color="primary"
              className={classes.addButton}
              startIcon={<AddCircleOutlineIcon />}
            >
              Adicionar Fluxo
            </Button>
          </Box>
        </MainHeaderButtonsWrapper>
      </MainHeader>

      <Fade in={true} timeout={500}>
        <Paper
          className={classes.mainPaper}
          variant="outlined"
          onScroll={handleScroll}
        >
          {webhooks.length > 0 && (
            <Box mb={2} display="flex" justifyContent="flex-end">
              <Typography variant="body2" color="textSecondary">
                {hasMore 
                  ? `Mostrando ${webhooks.length} fluxos de um total maior`
                  : `${webhooks.length} fluxo${webhooks.length !== 1 ? 's' : ''} no total`
                }
              </Typography>
            </Box>
          )}

          {loading ? (
            <Box display="flex" justifyContent="center" alignItems="center" p={4}>
              <CircularProgress />
            </Box>
          ) : webhooks.length > 0 ? (
            <Box className={classes.flowsContainer}>
              {webhooks.map((flow) => (
                <Box 
                  key={flow.id} 
                  className={classes.flowItem}
                  onClick={() => history.push(`/flowbuilder/${flow.id}`)}
                >
                  <Typography variant="subtitle1" className={classes.flowName}>
                    <OfflineBoltIcon className={classes.flowIcon} />
                    {flow.name}
                  </Typography>
                  
                  <IconButton
                    size="small"
                    className={classes.actionButton}
                    onClick={(e) => handleClick(e, flow)}
                  >
                    <MoreVertIcon fontSize="small" />
                  </IconButton>
                </Box>
              ))}
            </Box>
          ) : (
            <Box className={classes.emptyState}>
              <Typography variant="body1" gutterBottom>
                Nenhum fluxo encontrado
              </Typography>
              <Button 
                variant="outlined" 
                color="primary" 
                onClick={handleOpenContactModal}
                style={{ marginTop: 16 }}
                startIcon={<AddCircleOutlineIcon />}
              >
                Adicionar primeiro fluxo
              </Button>
            </Box>
          )}

          <Menu
            id="flow-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
          >
            <MenuItem 
              onClick={() => {
                handleClose();
                hadleEditContact();
              }}
              className={classes.menuItem}
            >
              <EditIcon fontSize="small" className={classes.menuIcon} />
              Editar nome
            </MenuItem>
            <MenuItem 
              onClick={() => {
                handleClose();
                exportLink();
              }}
              className={classes.menuItem}
            >
              <BuildIcon fontSize="small" className={classes.menuIcon} />
              Editar fluxo
            </MenuItem>
            <Divider className={classes.divider} />
            <MenuItem 
              onClick={() => {
                handleClose();
                setConfirmDuplicateOpen(true);
              }}
              className={classes.menuItem}
            >
              <FileCopyIcon fontSize="small" className={classes.menuIcon} />
              Duplicar
            </MenuItem>
            <MenuItem 
              onClick={() => {
                handleClose();
                setConfirmOpen(true);
              }}
              className={classes.menuItem}
            >
              <DeleteOutlineIcon fontSize="small" className={classes.menuIcon} />
              Excluir
            </MenuItem>
          </Menu>
        </Paper>
      </Fade>
    </MainContainer>
  );
};

export default FlowBuilder;
