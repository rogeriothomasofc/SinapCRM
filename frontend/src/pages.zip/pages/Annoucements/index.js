import React, { useState, useEffect, useReducer, useContext } from "react";
import { toast } from "react-toastify";
import { useHistory } from "react-router-dom";

import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import IconButton from "@material-ui/core/IconButton";
import TextField from "@material-ui/core/TextField";
import InputAdornment from "@material-ui/core/InputAdornment";
import { Grid, Tooltip } from "@material-ui/core";

// Ícones modernos (Rounded)
import SearchRoundedIcon from "@material-ui/icons/SearchRounded";
import DeleteRoundedIcon from "@material-ui/icons/DeleteRounded";
import EditRoundedIcon from "@material-ui/icons/EditRounded";
import AddRoundedIcon from "@material-ui/icons/AddRounded";
import PriorityHighRoundedIcon from "@material-ui/icons/PriorityHighRounded";
import AttachFileRoundedIcon from "@material-ui/icons/AttachFileRounded";
import CheckCircleRoundedIcon from "@material-ui/icons/CheckCircleRounded";
import CancelRoundedIcon from "@material-ui/icons/CancelRounded";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";

import api from "../../services/api";
import { i18n } from "../../translate/i18n";
import TableRowSkeleton from "../../components/TableRowSkeleton";
import AnnouncementModal from "../../components/AnnouncementModal";
import ConfirmationModal from "../../components/ConfirmationModal";
import toastError from "../../errors/toastError";
import { isArray } from "lodash";
import { SocketContext } from "../../context/Socket/SocketContext";
import { AuthContext } from "../../context/Auth/AuthContext";

const reducer = (state, action) => {
  if (action.type === "LOAD_ANNOUNCEMENTS") {
    const announcements = action.payload;
    const newAnnouncements = [];

    if (isArray(announcements)) {
      announcements.forEach((announcement) => {
        const announcementIndex = state.findIndex(
          (u) => u.id === announcement.id
        );
        if (announcementIndex !== -1) {
          state[announcementIndex] = announcement;
        } else {
          newAnnouncements.push(announcement);
        }
      });
    }

    return [...state, ...newAnnouncements];
  }

  if (action.type === "UPDATE_ANNOUNCEMENTS") {
    const announcement = action.payload;
    const announcementIndex = state.findIndex((u) => u.id === announcement.id);

    if (announcementIndex !== -1) {
      state[announcementIndex] = announcement;
      return [...state];
    } else {
      return [announcement, ...state];
    }
  }

  if (action.type === "DELETE_ANNOUNCEMENT") {
    const announcementId = action.payload;

    const announcementIndex = state.findIndex((u) => u.id === announcementId);
    if (announcementIndex !== -1) {
      state.splice(announcementIndex, 1);
    }
    return [...state];
  }

  if (action.type === "RESET") {
    return [];
  }
};

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.padding || theme.spacing(1),
    overflowY: "scroll",
    ...theme.scrollbarStyles,
    borderRadius: 8,
  },
  searchContainer: {
    display: "flex",
    alignItems: "center",
    width: "100%",
  },
  searchInput: {
    flex: 1,
    marginRight: theme.spacing(1),
  },
  addButton: {
    height: 40,
    boxShadow: "none",
    fontSize: "0.9rem",
    fontWeight: 500,
  },
  tableContainer: {
    "& th": {
      fontWeight: 600,
      color: theme.mode === 'dark' ? 'rgba(255, 255, 255, 0.8)' : theme.palette.text.primary,
      fontSize: "0.9rem",
    },
  },
  tableCell: {
    padding: theme.spacing(1),
    fontSize: "0.9rem",
  },
  priorityHigh: {
    color: theme.palette.error.main,
  },
  priorityMedium: {
    color: theme.palette.warning.main,
  },
  priorityLow: {
    color: theme.palette.info.main,
  },
  statusActive: {
    color: theme.palette.success.main,
  },
  statusInactive: {
    color: theme.palette.text.disabled,
  },
  actionButton: {
    padding: theme.spacing(1),
  },
  actionIcon: {
    fontSize: "1.2rem",
  },
}));

const Announcements = () => {
  const classes = useStyles();
  const history = useHistory();

  const { user } = useContext(AuthContext);

  const [loading, setLoading] = useState(false);
  const [pageNumber, setPageNumber] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState(null);
  const [deletingAnnouncement, setDeletingAnnouncement] = useState(null);
  const [announcementModalOpen, setAnnouncementModalOpen] = useState(false);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [searchParam, setSearchParam] = useState("");
  const [announcements, dispatch] = useReducer(reducer, []);

  const socketManager = useContext(SocketContext);

  // trava para nao acessar pagina que não pode  
  useEffect(() => {
    async function fetchData() {
      if (!user.super) {
        toast.error(i18n.t("announcements.toasts.info"));
        setTimeout(() => {
          history.push(`/`)
        }, 1000);
      }
    }
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    dispatch({ type: "RESET" });
    setPageNumber(1);
  }, [searchParam]);

  useEffect(() => {
    setLoading(true);
    const delayDebounceFn = setTimeout(() => {
      fetchAnnouncements();
    }, 500);
    return () => clearTimeout(delayDebounceFn);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParam, pageNumber]);

  useEffect(() => {
    const companyId = user.companyId;
    const socket = socketManager.getSocket(companyId);

    socket.on(`company-announcement`, (data) => {
      if (data.action === "update" || data.action === "create") {
        dispatch({ type: "UPDATE_ANNOUNCEMENTS", payload: data.record });
      }
      if (data.action === "delete") {
        dispatch({ type: "DELETE_ANNOUNCEMENT", payload: +data.id });
      }
    });
    return () => {
      socket.disconnect();
    };
  }, [socketManager, user.companyId]);

  const fetchAnnouncements = async () => {
    try {
      const { data } = await api.get("/announcements/", {
        params: { searchParam, pageNumber },
      });
      dispatch({ type: "LOAD_ANNOUNCEMENTS", payload: data.records });
      setHasMore(data.hasMore);
      setLoading(false);
    } catch (err) {
      toastError(err);
    }
  };

  const handleOpenAnnouncementModal = () => {
    setSelectedAnnouncement(null);
    setAnnouncementModalOpen(true);
  };

  const handleCloseAnnouncementModal = () => {
    setSelectedAnnouncement(null);
    setAnnouncementModalOpen(false);
  };

  const handleSearch = (event) => {
    setSearchParam(event.target.value.toLowerCase());
  };

  const handleEditAnnouncement = (announcement) => {
    setSelectedAnnouncement(announcement);
    setAnnouncementModalOpen(true);
  };

  const handleDeleteAnnouncement = async (announcement) => {
    try {
      if (announcement.mediaName)
        await api.delete(`/announcements/${announcement.id}/media-upload`);

      await api.delete(`/announcements/${announcement.id}`);
      
      toast.success(i18n.t("announcements.toasts.deleted"));
    } catch (err) {
      toastError(err);
    }
    setDeletingAnnouncement(null);
    setSearchParam("");
    setPageNumber(1);
  };

  const loadMore = () => {
    setPageNumber((prevState) => prevState + 1);
  };

  const handleScroll = (e) => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - (scrollTop + 100) < clientHeight) {
      loadMore();
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 1:
        return <PriorityHighRoundedIcon className={classes.priorityHigh} fontSize="small" />;
      case 2:
        return <PriorityHighRoundedIcon className={classes.priorityMedium} fontSize="small" />;
      case 3:
        return <PriorityHighRoundedIcon className={classes.priorityLow} fontSize="small" />;
      default:
        return null;
    }
  };

  const getStatusIcon = (status) => {
    return status ? 
      <CheckCircleRoundedIcon className={classes.statusActive} fontSize="small" /> : 
      <CancelRoundedIcon className={classes.statusInactive} fontSize="small" />;
  };

  const translatePriority = (val) => {
    if (val === 1) {
      return i18n.t("announcements.high");
    }
    if (val === 2) {
      return i18n.t("announcements.medium");
    }
    if (val === 3) {
      return i18n.t("announcements.low");
    }
  };

  return (
    <MainContainer>
      <ConfirmationModal
        title={
          deletingAnnouncement &&
          `${i18n.t("announcements.confirmationModal.deleteTitle")} ${deletingAnnouncement.name
          }?`
        }
        open={confirmModalOpen}
        onClose={setConfirmModalOpen}
        onConfirm={() => handleDeleteAnnouncement(deletingAnnouncement)}
      >
        {i18n.t("announcements.confirmationModal.deleteMessage")}
      </ConfirmationModal>
      <AnnouncementModal
        resetPagination={() => {
          setPageNumber(1);
          fetchAnnouncements();
        }}
        open={announcementModalOpen}
        onClose={handleCloseAnnouncementModal}
        aria-labelledby="form-dialog-title"
        announcementId={selectedAnnouncement && selectedAnnouncement.id}
      />
      <MainHeader>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={6}>
            <Title>{i18n.t("announcements.title")} ({announcements.length})</Title>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Grid container spacing={2}>
              <Grid item xs={7}>
                <TextField
                  fullWidth
                  variant="outlined"
                  size="small"
                  placeholder={i18n.t("announcements.searchPlaceholder")}
                  type="search"
                  value={searchParam}
                  onChange={handleSearch}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchRoundedIcon color="action" />
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
              <Grid item xs={5}>
                <Button
                  fullWidth
                  variant="contained"
                  color="primary"
                  className={classes.addButton}
                  onClick={handleOpenAnnouncementModal}
                  startIcon={<AddRoundedIcon />}
                >
                  {i18n.t("announcements.buttons.add")}
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </MainHeader>
      <Paper
        className={classes.mainPaper}
        variant="outlined"
        onScroll={handleScroll}
      >
        <Table size="small" className={classes.tableContainer}>
          <TableHead>
            <TableRow>
              <TableCell align="left">
                {i18n.t("announcements.table.title")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("announcements.table.priority")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("announcements.table.mediaName")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("announcements.table.status")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("announcements.table.actions")}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <>
              {announcements.map((announcement) => (
                <TableRow key={announcement.id}>
                  <TableCell align="left" className={classes.tableCell}>
                    {announcement.title}
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {getPriorityIcon(announcement.priority)}
                      <span style={{ marginLeft: 8 }}>
                        {translatePriority(announcement.priority)}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    {announcement.mediaName ? (
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <AttachFileRoundedIcon fontSize="small" style={{ marginRight: 8 }} />
                        {announcement.mediaName}
                      </div>
                    ) : (
                      i18n.t("quickMessages.noAttachment")
                    )}
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {getStatusIcon(announcement.status)}
                      <span style={{ marginLeft: 8 }}>
                        {announcement.status ? i18n.t("announcements.active") : i18n.t("announcements.inactive")}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell align="center" className={classes.tableCell}>
                    <Tooltip title={i18n.t("announcements.buttons.edit")}>
                      <IconButton
                        size="small"
                        className={classes.actionButton}
                        onClick={() => handleEditAnnouncement(announcement)}
                      >
                        <EditRoundedIcon fontSize="small" className={classes.actionIcon} />
                      </IconButton>
                    </Tooltip>

                    <Tooltip title={i18n.t("announcements.buttons.delete")}>
                      <IconButton
                        size="small"
                        className={classes.actionButton}
                        onClick={() => {
                          setConfirmModalOpen(true);
                          setDeletingAnnouncement(announcement);
                        }}
                      >
                        <DeleteRoundedIcon fontSize="small" className={classes.actionIcon} />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
              {loading && <TableRowSkeleton columns={5} />}
            </>
          </TableBody>
        </Table>
      </Paper>
    </MainContainer>
  );
};

export default Announcements;