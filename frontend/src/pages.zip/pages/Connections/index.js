import React, { useState, useCallback, useContext } from "react";
import { toast } from "react-toastify";

import { makeStyles } from "@material-ui/core/styles";
import { green, red, orange } from "@material-ui/core/colors";
import {
  Button,
  IconButton,
  Paper,
  Tooltip,
  Typography,
  CircularProgress,
  Box,
  Fade,
  Chip,
  useTheme,
} from "@material-ui/core";

import {
  Edit,
  CheckCircle,
  SignalCellularConnectedNoInternet2Bar,
  SignalCellularConnectedNoInternet0Bar,
  SignalCellular4Bar,
  CropFree,
  DeleteOutline,
  WhatsApp,
  Add,
  Refresh,
  Block,
  Phone,
} from "@material-ui/icons";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";

import api from "../../services/api";
import WhatsAppModal from "../../components/WhatsAppModal";
import ConfirmationModal from "../../components/ConfirmationModal";
import QrcodeModal from "../../components/QrcodeModal";
import { i18n } from "../../translate/i18n";
import { WhatsAppsContext } from "../../context/WhatsApp/WhatsAppsContext";
import toastError from "../../errors/toastError";

import { AuthContext } from "../../context/Auth/AuthContext";
import { Can } from "../../components/Can";

const useStyles = makeStyles(theme => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(1.5),
    overflowY: "auto",
    backgroundColor: theme.palette.background.default,
    ...theme.scrollbarStyles,
  },
  connectionRow: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(1, 1.5),
    marginBottom: theme.spacing(0.5),
    borderRadius: 6,
    border: `1px solid ${theme.palette.divider}`,
    backgroundColor: theme.palette.background.paper,
    transition: "all 0.2s ease",
    minHeight: 48,
    "&:hover": {
      backgroundColor: theme.palette.action.hover,
      borderColor: theme.palette.primary.main,
      "& $actionButtons": {
        opacity: 1,
      },
    },
  },
  connectionInfo: {
    display: "flex",
    alignItems: "center",
    flex: 1,
    gap: theme.spacing(1.5),
  },
  whatsappIcon: {
    color: "#25D366",
    fontSize: 24,
  },
  connectionDetails: {
    flex: 1,
    minWidth: 0,
  },
  connectionName: {
    fontWeight: 500,
    fontSize: "0.875rem",
    color: theme.palette.text.primary,
    marginBottom: 2,
    display: "flex",
    alignItems: "center",
  },
  phoneNumber: {
    fontSize: "0.75rem",
    color: theme.palette.text.secondary,
  },
  connectionStatus: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
  },
  statusChip: {
    height: 20,
    fontSize: "0.7rem",
    fontWeight: 500,
    "& .MuiChip-label": {
      padding: "0 8px",
    },
  },
  connectedChip: {
    backgroundColor: green[100],
    color: green[800],
  },
  disconnectedChip: {
    backgroundColor: red[100],
    color: red[800],
  },
  connectingChip: {
    backgroundColor: orange[100],
    color: orange[800],
  },
  qrcodeChip: {
    backgroundColor: theme.palette.info.light,
    color: theme.palette.info.dark,
  },
  centerSection: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    minWidth: 200,
    marginRight: theme.spacing(2),
  },
  lastUpdate: {
    fontSize: "0.7rem",
    color: theme.palette.text.secondary,
  },
  defaultBadge: {
    color: green[600],
    fontSize: 14,
    marginLeft: 6,
  },
  actionButtons: {
    display: "flex",
    gap: theme.spacing(0.5),
    opacity: 0,
    transition: "opacity 0.2s ease",
  },
  iconButton: {
    padding: 5,
    "& .MuiSvgIcon-root": {
      fontSize: "1.2rem",
    },
    "&:hover": {
      backgroundColor: theme.palette.action.hover,
    },
  },
  qrButton: {
    borderRadius: 4,
    textTransform: "none",
    fontSize: "0.75rem",
    padding: "4px 12px",
  },
  addButton: {
    borderRadius: 6,
    textTransform: "none",
    fontWeight: 500,
    padding: "6px 16px",
    fontSize: "0.875rem",
    boxShadow: "none",
    "&:hover": {
      boxShadow: theme.shadows[2],
    },
  },
  emptyState: {
    textAlign: "center",
    padding: theme.spacing(6),
    color: theme.palette.text.secondary,
  },
  loadingContainer: {
    display: "flex",
    justifyContent: "center",
    padding: theme.spacing(3),
  },
  headerContent: {
    display: "flex",
    alignItems: "center",
    gap: theme.spacing(1),
  },
  connectionCounter: {
    backgroundColor: theme.palette.action.hover,
    borderRadius: 12,
    padding: "2px 10px",
    fontSize: "0.8125rem",
    fontWeight: 500,
    color: theme.palette.text.secondary,
  },
}));

const Connections = () => {
  const classes = useStyles();
  const theme = useTheme();

  const { user } = useContext(AuthContext);
  const { whatsApps, loading } = useContext(WhatsAppsContext);
  const [whatsAppModalOpen, setWhatsAppModalOpen] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [selectedWhatsApp, setSelectedWhatsApp] = useState(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  
  const confirmationModalInitialState = {
    action: "",
    title: "",
    message: "",
    whatsAppId: "",
    open: false,
  };
  const [confirmModalInfo, setConfirmModalInfo] = useState(
    confirmationModalInitialState
  );

  const handleStartWhatsAppSession = async whatsAppId => {
    try {
      await api.post(`/whatsappsession/${whatsAppId}`);
    } catch (err) {
      toastError(err);
    }
  };

  const handleRequestNewQrCode = async whatsAppId => {
    try {
      await api.put(`/whatsappsession/${whatsAppId}`);
    } catch (err) {
      toastError(err);
    }
  };

  const handleOpenWhatsAppModal = () => {
    setSelectedWhatsApp(null);
    setWhatsAppModalOpen(true);
  };

  const handleCloseWhatsAppModal = useCallback(() => {
    setWhatsAppModalOpen(false);
    setSelectedWhatsApp(null);
  }, [setSelectedWhatsApp, setWhatsAppModalOpen]);

  const handleOpenQrModal = whatsApp => {
    setSelectedWhatsApp(whatsApp);
    setQrModalOpen(true);
  };

  const handleCloseQrModal = useCallback(() => {
    setSelectedWhatsApp(null);
    setQrModalOpen(false);
  }, [setQrModalOpen, setSelectedWhatsApp]);

  const handleEditWhatsApp = whatsApp => {
    setSelectedWhatsApp(whatsApp);
    setWhatsAppModalOpen(true);
  };

  const handleOpenConfirmationModal = (action, whatsAppId) => {
    if (action === "disconnect") {
      setConfirmModalInfo({
        action: action,
        title: i18n.t("connections.confirmationModal.disconnectTitle"),
        message: i18n.t("connections.confirmationModal.disconnectMessage"),
        whatsAppId: whatsAppId,
      });
    }

    if (action === "delete") {
      setConfirmModalInfo({
        action: action,
        title: i18n.t("connections.confirmationModal.deleteTitle"),
        message: i18n.t("connections.confirmationModal.deleteMessage"),
        whatsAppId: whatsAppId,
      });
    }
    setConfirmModalOpen(true);
  };

  const handleSubmitConfirmationModal = async () => {
    if (confirmModalInfo.action === "disconnect") {
      try {
        await api.delete(`/whatsappsession/${confirmModalInfo.whatsAppId}`);
      } catch (err) {
        toastError(err);
      }
    }

    if (confirmModalInfo.action === "delete") {
      try {
        await api.delete(`/whatsapp/${confirmModalInfo.whatsAppId}`);
        toast.success(i18n.t("connections.toasts.deleted"));
      } catch (err) {
        toastError(err);
      }
    }

    setConfirmModalInfo(confirmationModalInitialState);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${day}/${month} ${hours}:${minutes}`;
  };

  const getStatusChip = (status) => {
    const statusLabels = {
      CONNECTED: "Conectado",
      DISCONNECTED: "Desconectado",
      OPENING: "Conectando",
      qrcode: "QR Code",
      TIMEOUT: "Timeout",
      PAIRING: "Pareando"
    };
    
    switch (status) {
      case "CONNECTED":
        return (
          <Chip
            size="small"
            label={i18n.t("connections.status.connected") || statusLabels.CONNECTED}
            className={`${classes.statusChip} ${classes.connectedChip}`}
          />
        );
      case "DISCONNECTED":
        return (
          <Chip
            size="small"
            label={i18n.t("connections.status.disconnected") || statusLabels.DISCONNECTED}
            className={`${classes.statusChip} ${classes.disconnectedChip}`}
          />
        );
      case "OPENING":
        return (
          <Chip
            size="small"
            label={i18n.t("connections.status.connecting") || statusLabels.OPENING}
            className={`${classes.statusChip} ${classes.connectingChip}`}
            icon={<CircularProgress size={12} style={{ color: orange[800] }} />}
          />
        );
      case "qrcode":
        return (
          <Chip
            size="small"
            label={i18n.t("connections.status.qrcode") || statusLabels.qrcode}
            className={`${classes.statusChip} ${classes.qrcodeChip}`}
          />
        );
      case "TIMEOUT":
      case "PAIRING":
        return (
          <Chip
            size="small"
            label={i18n.t("connections.status.timeout") || statusLabels.TIMEOUT}
            className={`${classes.statusChip} ${classes.connectingChip}`}
          />
        );
      default:
        return null;
    }
  };

  const renderActionButtons = whatsApp => {
    return null; // Removida pois agora os botões estão distribuídos na interface
  };

  return (
    <MainContainer>
      <ConfirmationModal
        title={confirmModalInfo.title}
        open={confirmModalOpen}
        onClose={setConfirmModalOpen}
        onConfirm={handleSubmitConfirmationModal}
      >
        {confirmModalInfo.message}
      </ConfirmationModal>
      
      <QrcodeModal
        open={qrModalOpen}
        onClose={handleCloseQrModal}
        whatsAppId={!whatsAppModalOpen && selectedWhatsApp?.id}
      />
      
      <WhatsAppModal
        open={whatsAppModalOpen}
        onClose={handleCloseWhatsAppModal}
        whatsAppId={!qrModalOpen && selectedWhatsApp?.id}
      />
      
      <MainHeader>
        <Box className={classes.headerContent}>
          <Title>{i18n.t("connections.title")}</Title>
          {whatsApps?.length > 0 && (
            <span className={classes.connectionCounter}>{whatsApps.length}</span>
          )}
        </Box>
        
        <MainHeaderButtonsWrapper>
          <Can
            role={user.profile}
            perform="connections-page:addConnection"
            yes={() => (
              <Button
                variant="contained"
                color="primary"
                onClick={handleOpenWhatsAppModal}
                startIcon={<WhatsApp />}
                className={classes.addButton}
                size="small"
              >
                {i18n.t("connections.buttons.add")}
              </Button>
            )}
          />
        </MainHeaderButtonsWrapper>
      </MainHeader>
      
      <Paper className={classes.mainPaper} elevation={0}>
        {loading ? (
          <Box className={classes.loadingContainer}>
            <CircularProgress size={32} />
          </Box>
        ) : whatsApps?.length === 0 ? (
          <Box className={classes.emptyState}>
            <WhatsApp style={{ fontSize: 48, marginBottom: 16, opacity: 0.2 }} />
            <Typography variant="body1">
              {i18n.t("connections.noConnections") || "Nenhuma conexão configurada"}
            </Typography>
          </Box>
        ) : (
          <Box>
            {whatsApps.map((whatsApp, index) => (
              <Fade in={true} timeout={300 + index * 50} key={whatsApp.id}>
                <Box className={classes.connectionRow}>
                  <Box className={classes.connectionInfo}>
                    <WhatsApp className={classes.whatsappIcon} />
                    
                    <Box className={classes.connectionDetails}>
                      <Box style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <Typography className={classes.connectionName}>
                          {whatsApp.name}
                          {whatsApp.isDefault && (
                            <Tooltip title={i18n.t("connections.default")} arrow>
                              <CheckCircle className={classes.defaultBadge} />
                            </Tooltip>
                          )}
                        </Typography>
                        {whatsApp.number && (
                          <Typography className={classes.phoneNumber}>
                            • {whatsApp.number}
                          </Typography>
                        )}
                      </Box>
                      {getStatusChip(whatsApp.status)}
                    </Box>
                  </Box>

                  <Box className={classes.centerSection}>
                    {whatsApp.status === "qrcode" && (
                      <Can
                        role={user.profile}
                        perform="connections-page:actionButtons"
                        yes={() => (
                          <Button
                            size="small"
                            variant="contained"
                            color="primary"
                            onClick={() => handleOpenQrModal(whatsApp)}
                            className={classes.qrButton}
                            startIcon={<CropFree />}
                          >
                            {i18n.t("connections.buttons.qrcode")}
                          </Button>
                        )}
                      />
                    )}
                    {(whatsApp.status === "CONNECTED" || whatsApp.status === "PAIRING" || whatsApp.status === "TIMEOUT") && (
                      <Can
                        role={user.profile}
                        perform="connections-page:actionButtons"
                        yes={() => (
                          <Button
                            size="small"
                            variant="outlined"
                            color="secondary"
                            onClick={() => handleOpenConfirmationModal("disconnect", whatsApp.id)}
                            className={classes.qrButton}
                            startIcon={<Block />}
                          >
                            {i18n.t("connections.buttons.disconnect")}
                          </Button>
                        )}
                      />
                    )}
                    {whatsApp.status === "DISCONNECTED" && (
                      <Can
                        role={user.profile}
                        perform="connections-page:actionButtons"
                        yes={() => (
                          <Box style={{ display: "flex", gap: 8 }}>
                            <Button
                              size="small"
                              variant="outlined"
                              color="primary"
                              onClick={() => handleStartWhatsAppSession(whatsApp.id)}
                              className={classes.qrButton}
                              startIcon={<Refresh />}
                            >
                              {i18n.t("connections.buttons.tryAgain")}
                            </Button>
                            <Button
                              size="small"
                              variant="outlined"
                              onClick={() => handleRequestNewQrCode(whatsApp.id)}
                              className={classes.qrButton}
                              startIcon={<CropFree />}
                            >
                              {i18n.t("connections.buttons.newQr")}
                            </Button>
                          </Box>
                        )}
                        no={() => (
                          <Typography className={classes.lastUpdate}>
                            {formatDate(whatsApp.updatedAt)}
                          </Typography>
                        )}
                      />
                    )}
                    {whatsApp.status === "OPENING" && (
                      <Typography className={classes.lastUpdate}>
                        {formatDate(whatsApp.updatedAt)}
                      </Typography>
                    )}
                  </Box>

                  <Box className={classes.actionButtons}>
                    <Can
                      role={user.profile}
                      perform="connections-page:actionButtons"
                      yes={() => (
                        <>
                          {whatsApp.status === "DISCONNECTED" && (
                            <></>
                          )}
                          {(whatsApp.status === "CONNECTED" || whatsApp.status === "PAIRING" || whatsApp.status === "TIMEOUT") && (
                            <></>
                          )}
                        </>
                      )}
                    />
                    
                    <Can
                      role={user.profile}
                      perform="connections-page:editOrDeleteConnection"
                      yes={() => (
                        <>
                          <Tooltip title={i18n.t("connections.buttons.edit")} arrow>
                            <IconButton
                              size="small"
                              className={classes.iconButton}
                              onClick={() => handleEditWhatsApp(whatsApp)}
                            >
                              <Edit />
                            </IconButton>
                          </Tooltip>

                          <Tooltip title={i18n.t("connections.buttons.delete")} arrow>
                            <IconButton
                              size="small"
                              className={classes.iconButton}
                              onClick={() => handleOpenConfirmationModal("delete", whatsApp.id)}
                            >
                              <DeleteOutline />
                            </IconButton>
                          </Tooltip>
                        </>
                      )}
                    />
                  </Box>
                </Box>
              </Fade>
            ))}
          </Box>
        )}
      </Paper>
    </MainContainer>
  );
};

export default Connections;